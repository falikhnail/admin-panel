<?php

namespace App\Models;

class SessionKeyModel{
    public const USER_LOGIN = "userLogin";
}
